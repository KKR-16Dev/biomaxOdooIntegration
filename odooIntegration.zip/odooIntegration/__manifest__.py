# -*- coding: utf-8 -*-
{
    "name": "BioMax Integration With Odoo",
    "summary": "BioMax Integration with Odoo Community v18",
    "version": "1.0",
    "author": "KKR",
    "website": "https://www.kaviglobal.com",
    "license": "LGPL-3",
    "category": 'Human Resources/Attendances',
    "depends": ["base", "hr", "hr_attendance"],
    "data": [
        "views/zoho_employee.xml",
    ],
    "assets": {},
    "application": False,
    "installable": True,
}
