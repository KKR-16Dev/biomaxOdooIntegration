# -*- coding: utf-8 -*-
{
    "name": "Biometric Integration With Odoo",
    "summary": "Biometric Integration with Odoo Community v18",
    "version": "1.0",
    "author": "KKR",
    "website": "https://www.kaviglobal.com",
    "license": "LGPL-3",
    "category": 'Human Resources/Attendances',
    "depends": ["base", "hr_attendance"],
    "data": [
        "views/attendance_button.xml",
    ],
    "assets": {},
    "application": False,
    "installable": True,
}
