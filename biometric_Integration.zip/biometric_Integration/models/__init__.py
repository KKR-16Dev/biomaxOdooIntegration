# from . import res_company
# from . import fetch_biometicdata
from . import fetch_biometricdata2
# from . import fetch_biometricdata3